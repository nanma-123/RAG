# Debyez AI Intern Assessment - RAG System

A containerized, agentic Document Question-Answering system built with FastAPI, LangChain, Weaviate, and Ollama.

## Features
- **Document Ingestion**: Supports PDF ingestion with extraction of text, tables, and images.
- **Agentic RAG**: Implements Query Decomposition and Answer Synthesis for enhanced retrieval accuracy.
- **Local LLM**: Uses Ollama (Llama 3) for inference and embedding.
- **Evaluation**: Includes `ragas` based evaluation notebook.
- **Dockerized**: specific `docker-compose.yml` for easy deployment.

## Prerequisites
- **Docker Desktop** (Must be running)
- **Ollama** (If running locally, otherwise managed by Docker)
- **Python 3.10+** (For local development/evaluation)

## Setup & Run

### Method 1: Docker (Preferred)
1.  Ensure Docker Desktop is running.
2.  Start the services:
    ```bash
    docker-compose up --build
    ```
    *Note: This starts Weaviate, Ollama, and the FastAPI App.*

3.  Download the LLM model (inside the running ollama container):
    ```bash
    docker exec -it <ollama_container_id> ollama pull llama3
    ```

### Method 2: Local Development
1.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```
2.  Start infrastructure (Weaviate & Ollama):
    *You can use the docker-compose for just the services:*
    ```bash
    docker-compose up weaviate ollama -d
    ```
3.  Run the API:
    ```bash
    uvicorn rag_app:app --reload
    ```

## Usage

### Ingest a Document
POST `/ingest` with a PDF file.
```bash
curl -X POST "http://localhost:8000/ingest" -F "file=@Assessment.pdf"
```

### Query the System
POST `/query` with a JSON body.
```json
{
  "query": "What are the evaluation metrics?"
}
```

## Evaluation
Run the Jupyter notebook `evaluation.ipynb` to assess the RAG pipeline using Ragas metrics.

## Architecture
See [ARCHITECTURE.md](ARCHITECTURE.md) for details on the system design and evaluation report.
